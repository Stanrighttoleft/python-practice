# EX 1: input() function to take user input
 

# EX 2: min() function to find the minimum value
numbers = [3, 1, 5, 2, 4]
 

# EX 3: max() function to find the maximum value

# EX 4: sum() function to calculate the sum of elements
 

# EX 5: int() function to convert a string to an integer
str_number = "10"
 

# EX 6: float() function to convert a string to a float
str_float = "3.14"
 

# EX 7: str() function to convert a number to a string
num = 123
 

# EX 8: list() function to convert a tuple to a list
tuple_values = (1, 2, 3)

# EX 9: set() function to create a set from a list
list_duplicates = [1, 2, 3, 1, 2, 3]
 

# EX 10: tuple() function to convert a list to a tuple
list_items = [4, 5, 6]
 

# EX 11: len() function to get the length of a string
string_length = len("hello")
 

# EX 12: len() function to get the length of a list
numbers = [3, 1, 5, 2, 4]

# EX 13: len() function to get the length of a tuple
numbers = (3, 1, 5, 2, 4)


# EX 14: len() function to get the length of a set
numbers = {3, 1, 5, 2, 4}

# EX 15: abs() function to get the absolute value
num = -20

# EX 16: sorted() function to sort a list
unsorted_list = [3, 1, 5, 2, 4]


# EX 17: reversed() function to reverse a list
unsorted_list = [3, 1, 5, 2, 4]


# EX 18: any() function to check if any element is true
bool_values = [False, True, False]


# EX 19: all() function to check if all elements are true
bool_values = [False, True, False]
 

# EX 20: zip() function to combine lists into tuples
letters = ['a', 'b', 'c']
numbers = [1, 2, 3]