# EX 1: Append 'apple' to the fruits list


# EX 2: Insert 'cherry' at index 1 in the fruits list

# EX 3: Remove 'banana' from the fruits list

# EX 4: Pop the last element from the fruits list

# EX 5: Sort the numbers list in ascending order

# EX 6: Reverse the numbers list

# EX 7: Count the occurrences of 2 in the numbers list

# EX 8: Extend the first list with elements from the second list

# EX 9: Find the index of 'orange' in the fruits list

# EX 10: Clear all elements from the fruits list
