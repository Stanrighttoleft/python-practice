# EX 1: Convert the string to uppercase

# EX 2: Convert the string to lowercase

# EX 3: Capitalize the first letter of the string

# EX 4: Count the occurrences of 'o' in the string


# EX 5: Check if the string ends with 'world'


# EX 6: Replace 'world' with 'Python' in the string


# EX 7: Split the string by spaces


# EX 8: Join a list of strings with '-'


# EX 9: Check if the string contains only alphabetic characters

# EX 10: Reverse the string

